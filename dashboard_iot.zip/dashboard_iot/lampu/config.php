<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "admin";
$dbname = "iot_data";
 
$mysqli = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
 
?>
