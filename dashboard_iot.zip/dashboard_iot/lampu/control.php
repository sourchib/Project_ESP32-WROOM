<?php
include 'config.php';
$id = $_GET['id'];
$status_lampu = $_GET['status_lampu'];
mysqli_query($mysqli,"UPDATE lampu SET status_lampu='$status_lampu' WHERE id='$id'");
header("location:index.php");
?>
