<?php
include 'config.php';
$id = $_GET['id'];
$nilai_sensor=mysqli_query($mysqli,"SELECT status_lampu FROM lampu WHERE id='$id'");
 
if($val=mysqli_fetch_array($nilai_sensor)){
echo "#";
echo $val['status_lampu'];
echo "#@";
}
?>
