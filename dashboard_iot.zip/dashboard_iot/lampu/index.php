<?php
include 'config.php';
?>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

	<title>Fans Electronics IOT</title>
  </head>
  <body><br>
  	<div class="container p-2 mb-2 bg-info text-dark">
  	<div style="text-align: center;">
		<img src="lampu.png" width="250px">
	</div>
	<br>
	<br>
	<div style="text-align: center;">
	<button type="button" class="btn btn-success" onclick="window.location.href='control.php?id=1&status_lampu=no'">OFF
	</button>
	<button type="button" class="btn btn-danger" onclick="window.location.href='control.php?id=1&status_lampu=yes'">ON
	</button>
	</div>

	<div style="font-size: 30px; text-align: center;">
	<?php
	$data = mysqli_query($mysqli, "SELECT * FROM lampu WHERE id='1'");
	if($val=mysqli_fetch_array($data)){
	$hasil = $val['status_lampu'];
	if($hasil == 1){
	$status = "yes";
	}
	else {
	$status = "no";
	}
	echo $val['nama_lampu'];
	}
	?>
	</div>
	</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
  </body>
</html>